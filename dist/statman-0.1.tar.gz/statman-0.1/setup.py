from setuptools import setup

setup(name='statman',
      version='0.1',
      description='Gaussian distributions',
      packages=['statman'],
      zip_safe=False)