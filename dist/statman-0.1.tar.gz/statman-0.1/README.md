# The Statman_package
## An evolutionary package for dealing with statistical distriutions easily in python
### Now, you can install the package and be able to carry out statistical analysis on various kinds of distributions including Gaussian, Binomial and various others


